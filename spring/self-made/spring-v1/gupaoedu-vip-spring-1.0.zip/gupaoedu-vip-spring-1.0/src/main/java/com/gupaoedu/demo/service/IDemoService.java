package com.gupaoedu.demo.service;


public interface IDemoService {
	
	String get(String name);
	
}
